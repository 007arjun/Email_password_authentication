package com.example.realmnew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import io.realm.Realm;

public class update extends AppCompatActivity {
    EditText cname, cdur, ctrk, cdesc;
    Button sub;
    private String sname,sdur,strk,sdesc;
    private Realm realm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        cname=findViewById(R.id.uname);
        cdur=findViewById(R.id.udur);
        ctrk=findViewById(R.id.utrack);
        cdesc=findViewById(R.id.udesc);


        realm=Realm.getDefaultInstance();

        sub=findViewById(R.id.uaddbtn);
    }
}